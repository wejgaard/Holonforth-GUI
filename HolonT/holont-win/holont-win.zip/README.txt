Welcome to HolonT. Just a few notes to ease the way.


INSTALLATION

When you read this, HolonT is already installed. There is nothing to set up.
(To get rid of HolonT, delete the HolonT directory.)


SYSTEM

There are three system files and a start utility.

- tclkit.exe -- is the brilliant selfcontained Tcl system that made Holon possible.

	(Tclkit is a product of equi4, see http://www.equi4.com/tclkit/index.html)

- holont.kit -- contains the HolonT system that is loaded into Tcl.

- source/holont.hdb -- is the project database of this demo HolonT system. 


RUN HOLON

Double-click holont.bat.


NOTES

The Tcl system tclkit.exe is used both for the development system and for 
the application. The application runs in a separate instance of tclkit.


The user's guide in HolonT has more information. 

--

Wolf Wejgaard
wolf@holonforth.com


